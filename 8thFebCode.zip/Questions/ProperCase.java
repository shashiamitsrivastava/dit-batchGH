package Questions;

import java.util.Scanner;

public class ProperCase {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Please enter a name");
        String name = scanner.nextLine();
        // String name = "shuBHAm ShARma";
        // Shubham Sharma
        String properName = "";
        String[] nameArray = name.split("");
        for (int i = 0; i < nameArray.length; i++) {
            String firstChar = String.valueOf(nameArray[i].charAt(0)).toUpperCase();
            String remainingName = nameArray[i].substring(1).toLowerCase();

            properName = properName + " " + firstChar + remainingName;
        }

        System.out.println("This is the proper name :" + properName);
    }
}
