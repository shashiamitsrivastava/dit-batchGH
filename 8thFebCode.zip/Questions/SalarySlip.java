package Questions;

import java.util.Scanner;

public class SalarySlip {

    static void takeInput() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Please enter your Employee ID");
        int empID = scanner.nextInt();
        scanner.nextLine();
        System.out.println("Please enter your name");
        String name = scanner.nextLine();
        System.out.println("Please enter your basic salaary");
        double basicSalary = scanner.nextDouble();
        calculate(basicSalary, name);

    }

    static String toProperCase(String name) {
        String properName = "";
        String[] nameArray = name.split(" ");
        for (int i = 0; i < nameArray.length; i++) {
            String firstChar = String.valueOf(nameArray[i].charAt(0)).toUpperCase();
            String remainingName = nameArray[i].substring(1).toLowerCase();

            properName = properName + " " + firstChar + remainingName;
        }
        return properName;
    }

    static double taxCalc(double basicSalary) {
        double totSal = basicSalary * 12;
        if (totSal < 500000) {
            return 0.02 * basicSalary;
        } else if (totSal > 500000 && totSal < 700000) {
            return 0.10 * basicSalary;
        } else if (totSal > 700000 && totSal < 1000000) {
            return 0.15 * basicSalary;
        }
        return 0.20 * basicSalary;
    }

    static void calculate(double basicSalary, String name) {
        double HRA = 0.50 * basicSalary;
        double TA = 0.30 * basicSalary;
        double DA = 0.25 * basicSalary;
        double MA = 0.20 * basicSalary;
        double PF = 0.10 * basicSalary;
        double TAX = taxCalc(basicSalary);
        String properCase = toProperCase(name);
        double gs = basicSalary + HRA + TA + DA + MA;
        double ns = gs - (TAX + PF);
        printData(properCase, HRA, TA, MA, DA, PF, TAX, gs, ns);
    }

    static void printData(String name, double HRA, double TA, double MA, double DA, double PF, double TAX, double gs,
            double ns) {
        System.out.println("Welcome, " + name);
        System.out.println("Earnings \t \t Deductions");
        System.out.println("HRA :" + HRA + " \t \t PF" + PF);
        System.out.println("DA :" + DA + " \t \t TAX" + TAX);
        System.out.println("TA :" + TA);
        System.out.println("MA :" + MA);
        System.out.println("This is the Gross Salary :" + gs);
        System.out.println("This is the Net Salary :" + ns);
    }

    public static void main(String[] args) {
        takeInput();
    }
}
