package Questions;

import java.util.Scanner;

public class SalarySlip {

    static void takeInput() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Please enter your Emp ID");
        int empId = scanner.nextInt();
        scanner.nextLine();
        System.out.println("Please enter your Name");
        String name = scanner.nextLine();
        System.out.println("Please enter your Basic Salary");
        double basicSalary = scanner.nextDouble();
        calculate(basicSalary, name);
    }

    static void calculate(double basicSalary, String name) {
        double HRA = 0.5 * basicSalary;
        double TA = 0.30 * basicSalary;
        double DA = 0.25 * basicSalary;
        double MA = 0.20 * basicSalary;
        double PF = 0.05 * basicSalary;
        double TAX = calTax(basicSalary);
        String properName = toProperCase(name);
        printData(HRA, TA, DA, MA, TAX, PF, properName);
    }

    static void printData(double HRA, double TA, double DA, double MA, double TAX, double PF, String name) {
        System.out.println("Welcome, " + name);
        System.out.println("This is the Salary Slip");

        System.out.println("Earning \t\t Deductions");
        System.out.println("HRA :" + HRA + "\t\t TAX: " + TAX);
        System.out.println("TA :" + TA + "\t\t PF :" + PF);
        System.out.println("DA :" + DA);
        System.out.println("MA :" + MA);
    }

    static double calTax(double basicSalary) {
        double totSal = basicSalary * 12;

        if (totSal < 500000) {
            return 0.0 * basicSalary;
        } else if (totSal > 500000 && totSal < 700000) {
            return 0.10 * basicSalary;
        } else if (totSal > 700000 && totSal < 1000000) {
            return 0.15 * basicSalary;
        }
        return 0.20 * basicSalary;
    }

    static String toProperCase(String name) {
        String nameArray[] = name.split(" ");
        String properName = "";
        for (int i = 0; i < nameArray.length; i++) {

            String firstChar = String.valueOf(nameArray[i].charAt(0)).toUpperCase();
            String remName = nameArray[i].substring(1).toLowerCase();

            properName = properName + " " + firstChar + remName;
        }
        return properName;
    }

    public static void main(String[] args) {
        takeInput();

        //to calc gross salary we have bs +hra+da+ta+ma
        // to net salary we have gs-(tax + pf)

        //Locale
    }
}
