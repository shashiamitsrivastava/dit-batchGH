package Questions;

public class Conditional {
    public static void main(String[] args) {
        int first = 10;
        int second = 45;
        int third = 66;

        if (first > second) {
            if (first > third) {
                System.out.println("FIRST");
            } else {
                System.out.println("THIRD");
            }
        } else {
            if (second > third) {
                System.out.println("SECOND");
            } else {
                System.out.println("THIRD");
            }
        }
    }
}
