package Questions;

public class PrintName {

    static void printN(int count, String name) {
        if (count == 0) {
            return;
        }
        System.out.println(count);
        printN(count - 1, name);
    }

    public static void main(String[] args) {
        printN(5, "SHUBHAM");
    }
}
