package Questions;

public class EvenOdd2 {

    static void findEvenOdd(int range) {
        if (range == 0) {
            return;
        }
        if (range % 2 == 0) {
            System.out.println(range +" the num is even");
        } else {
            System.out.println(range +" the number is odd");
        }
        findEvenOdd(range - 1);
    }

    public static void main(String[] args) {
        findEvenOdd(20);
    }
}
