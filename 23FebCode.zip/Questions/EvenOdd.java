package Questions;

public class EvenOdd {
    public static void main(String[] args) {
        int n = 41;

        if ((n ^ 1) == n + 1) {
            System.out.println("EVEN");
        } else {
            System.out.println("ODD");
        }

        if ((n | 1) == n + 1) {
            System.out.println("EVEN");
        } else {
            System.out.println("ODD");
        }

        if ((n & 1) == 0) {
            System.out.println("EVEN");
        } else {
            System.out.println("ODD");
        }
    }
}
