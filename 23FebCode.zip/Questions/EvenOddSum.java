package Questions;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Locale;

public class EvenOddSum {
    public static void main(String[] args) {
        int num = 1234;
        int evenSum = 0;
        int oddSum = 0;
        int count = 0;

        // while (num != 0) {
        // int last = num % 10;
        // count++;
        // if (count % 2 == 0) {
        // evenSum += last;
        // } else {
        // oddSum += last;
        // }
        // num/=10;
        // }

        // int i = 0;
        // while (i < 5) {
        //     System.out.print("Hi ");
        //     i = i++;
        // }

        Character a = 'Y';
        Character b = new Character('Y');
        System.out.println(a == b);
        // System.out.println("This is the odd sum :" + oddSum);
        // System.out.println("This is the even sum :" + evenSum);
    }
}
