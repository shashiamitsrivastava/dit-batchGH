package Questions;

public class Armstrong {
    public static void main(String[] args) {
        int n = 153;
        int nCopy = n;
        int nCopy2 = n;
        int count = 0;
        while (n != 0) {
            n = n / 10;
            count++;
        }

        int sum = 0;
        while (nCopy != 0) {
            int last = nCopy % 10;
            sum = sum + (int) Math.pow(last, count);
            nCopy = nCopy / 10;
        }

        if (sum == nCopy2) {
            System.out.println("Armstrong");
        } else {
            System.out.println("Not Armstrong");
        }
    }
}
