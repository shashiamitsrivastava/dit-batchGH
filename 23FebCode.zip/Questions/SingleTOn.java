package Questions;

class DOG {

   static DOG obj;

    private DOG() {

    }

   static DOG getInstance() {
        if (obj == null) {
            obj = new DOG();
        }
        return obj;
    }
}

public class SingleTOn {
    // DOG dog1 = new DOG();
    // DOG dog2 = new DOG();
    // DOG dog3 = new DOG();
    DOG dog1 = DOG.getInstance();

    String name = "Shubham"; // 77
    // String name2 = new String("Shubham");//88, 77
    String name2 = new String("Shubham").intern();//88, 77
}
