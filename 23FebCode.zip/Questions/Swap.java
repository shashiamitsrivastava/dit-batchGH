package Questions;

public class Swap {
    public static void main(String[] args) {
        int v = 123456;
        int nCopy = v;
        int count = 0;
        while (v != 0) {
            v = v / 10;
            count++;
        }

        int last = nCopy % 10;
        int front = nCopy / (int) Math.pow(10, count - 1);
        int center = (nCopy % (int) Math.pow(10, count - 1)) / 10;

        int res = (last * (int) Math.pow(10, count - 2) + center) * 10 + front;

        System.out.println("THis is the ans :" + res);
    }
}
