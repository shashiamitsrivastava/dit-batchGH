package Questions;

public class Roate {
    public static void main(String[] args) {
        int num = 12345;
        int numCpy = num;
        int rot = -2;

        int count = 0;
        while (num != 0) {
            num = num / 10;
            count++;
        }
        if (rot < 0) {
            rot = rot + count;
        }
        rot = rot % count;
        int rhs = numCpy % (int) Math.pow(10, rot);
        int lhs = numCpy / (int) Math.pow(10, rot);
        int res = rhs * (int) Math.pow(10, count - rot) + lhs;
        System.out.println("This is the rot :" + res);
    }
}
