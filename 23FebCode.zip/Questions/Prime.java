package Questions;

public class Prime {
    public static void main(String[] args) {
        int num = 19999;
        int factCount = 0;
        for (int i = 2; i < Math.sqrt(num); i++) {
            if (num % i == 0) {
                System.out.println("Not Prime");
                break;
            }
        }
        System.out.println("Not prime");
        // for (int i = 1; i <= num; i++) {
        // if (num % i == 0) {
        // factCount++;
        // }
        // }
        // if (factCount == 2) {
        // System.out.println("Prime");
        // } else {
        // System.out.println("Not Prime");
        // }
    }
}
