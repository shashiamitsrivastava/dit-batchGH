package Questions;

public class Temp {
    static String toProperCase(String name) {
        String properName = "";
        String[] nameArray = name.split(" ");
        for (int i = 0; i < nameArray.length; i++) {
            String firstChar = String.valueOf(nameArray[i].charAt(0)).toUpperCase();
            String remainingName = nameArray[i].substring(1).toLowerCase();

            properName = properName + " " + firstChar + remainingName;
        }
        return properName;
    }

    public static void main(String[] args) {
        toProperCase("shBHam SHArma");
    }
}
