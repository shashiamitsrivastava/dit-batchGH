package Questions;

public class RecDemo {

    static void printData(int count) {

        //this is the base case
        if (count == 0) {
            return;
        }

        // this is the logic
        System.out.println(count);

        // this is the small problem
        printData(count - 1);
    }

    public static void main(String[] args) {
        printData(10);
    }
}
