public class Power {

    static int findPower(int base, int exp) {
        if (exp == 0) {
            return 1;
        }
        return findPower(base, exp - 1) * base;
    }

    public static void main(String[] args) {

        System.out.println(findPower(2, 5));
    }
}
