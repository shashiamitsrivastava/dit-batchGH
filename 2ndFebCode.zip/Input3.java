import java.util.Scanner;

public class Input3 {
    public static void main(String[] args) {
        // Scanner scanner = new Scanner(System.in);
        // System.out.println("Roll no");
        // int roll = scanner.nextInt();
        // System.out.println("This is the roll :" + roll);
        // scanner.nextLine();
        // System.out.println("Name");
        // String name = scanner.nextLine();
        // System.out.println("This is the name :" + name);

        Scanner scanner = new Scanner("This is DIT");
        int count = 0;
        while (scanner.hasNext()) {
            // System.out.println(scanner.next());
            scanner.next();
            count++;
        }
        System.out.println("THis is the word count :" + count);
    }
}
