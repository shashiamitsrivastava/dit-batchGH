public class Second {
    public static void main(String... args) {
        // int a = 55;
        // int b = a;

        // String name = "Shubham";
        // String name2 = name;
        // String name3 = "Shubham";
        // String name4 = new String("Shubham").intern();
        // // System.out.println(name == name2);
        // // System.out.println(name == name3);
        // System.out.println(name == name4);

        // String name5 = new String("shyam").intern();
        // String name6 = "shyam";

        // String name = "Shyam";

        // // name.
        // String name2 = name;

        // String name4 = new String("SHYAM is agreakjbdckjdbfkjsdfkj,sn sfg");
        // String name3 = name2.toUpperCase();

        // // System.out.println(name == name2);
        // System.out.println(name == name3);
        // System.out.println(name3 == name4);

        // String name = "Shubham";
        // name = name + "Sharma";
        // name = name + "is good";

        // StringBuffer sb = new StringBuffer(50);
        StringBuilder sb = new StringBuilder(50);
        sb.append("Shubham");
        sb.append("Shubham");
        sb.append("Shubham");
        System.out.println(sb.capacity());
        System.out.println(sb.length());

    }

    void  sum() {

    }
}
