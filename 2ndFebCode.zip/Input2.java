import java.io.IOException;
import java.util.*;

public class Input2 {
    public static void main(String[] args) throws IOException {
        // System.out.println("Please enter a value");
        // // int val = System.in.read();
        // byte [] val = System.in.readAllBytes();
        // System.out.println("THis is the val :" + val);

        Scanner scanner = new Scanner(System.in);
        System.out.println("Name");
        String name = scanner.next();
        System.out.println("This is the name :" + name);
        System.out.println("Roll no");
        int roll = scanner.nextInt();
        System.out.println("This is the roll :" + roll);

    }
}
