 class ADD {
    public static void main(String[] args) {
        // String name = args[0];
        // String name2 = args[1];
        // System.out.println("This is the name :" + name + name2);

        // if (args.length == 2) {
        // int num1 = Integer.parseInt(args[0]);
        // int num2 = Integer.parseInt(args[1]);
        // int sum = num1 + num2;
        // System.out.println("This is the sum :" + sum);
        // } else {
        // System.out.println("Not a valid input");
        // }

        // int sum = 0;
        // for (int i = 0; i < args.length; i++) {
        //     sum = sum + Integer.parseInt(args[i]);
        // }

        char ch = 'A';
        int a = (int)ch;

        // System.out.println("This is the sum :" + sum);
        System.out.println(Integer.parseInt("n"));

    }
}
